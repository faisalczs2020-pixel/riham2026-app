export default {content:['./index.html','./src/**/*.{ts,tsx}'],theme:{extend:{colors:{gold:'#C9A55C',ink:'#111111',cream:'#F7F4EE'}}},plugins:[]}
