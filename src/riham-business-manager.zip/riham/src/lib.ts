import {useEffect,useState} from 'react'
import type {DB,Item,Order} from './types'

export const uid=()=>Math.random().toString(36).slice(2,9)+Date.now().toString(36).slice(-4)
export const money=(n:number)=>'৳'+Math.round(n).toLocaleString('en-IN')
export const today=()=>{const d=new Date();return new Date(d.getTime()-d.getTimezoneOffset()*6e4).toISOString().slice(0,10)}
export const fmtDate=(d:string)=>new Date(d+'T00:00').toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'})

// ---- calculations ----
export const sub=(items:Item[])=>items.reduce((s,i)=>s+i.qty*i.price,0)
export const subtotal=(o:Order)=>sub(o.items)
export const grand=(o:Order)=>subtotal(o)+o.delivery-o.discount          // Grand Total = Subtotal + Delivery - Discount
export const paid=(o:Order)=>o.payments.reduce((s,p)=>s+p.amount,0)
export const due=(o:Order)=>Math.max(0,grand(o)-paid(o))                  // Due = Grand Total - Advance/Paid
export const status=(o:Order)=>o.cancelled?'Cancelled':grand(o)>0&&paid(o)>=grand(o)?'Paid':paid(o)>0?'Partial':'Unpaid'

// ---- storage ----
const KEY='riham_db_v1'
export const defaults:DB={customers:[],products:[],orders:[],settings:{logo:'/logo.jpg',name:'RIHAM',tagline:'SCENTS YOU CHERISH, MOMENTS YOU REMEMBER.',phone:'',facebook:'',address:'',delivery:0,prefix:'RIH',counter:1}}
export const normalize=(x:any):DB=>({customers:x?.customers??[],products:x?.products??[],orders:x?.orders??[],settings:{...defaults.settings,...(x?.settings??{})}})
const load=():DB=>{try{const r=localStorage.getItem(KEY);if(r)return normalize(JSON.parse(r))}catch{}return defaults}
export function useDB(){
  const [db,setDb]=useState<DB>(load)
  useEffect(()=>{try{localStorage.setItem(KEY,JSON.stringify(db))}catch{alert('Storage is full — please download a backup and free some space.')}},[db])
  return [db,setDb] as const
}
export const markBackup=()=>localStorage.setItem('riham_last_backup',String(Date.now()))
export const lastBackup=()=>Number(localStorage.getItem('riham_last_backup')||0)

// ---- files ----
export function download(name:string,content:BlobPart,type:string){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([content],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),5000)}
const esc=(v:unknown)=>`"${String(v??'').replace(/"/g,'""')}"`
export function ordersCsv(orders:Order[]){
  const h=['Order ID','Date','Customer','Phone','Address','Items','Subtotal','Delivery','Discount','Grand Total','Paid','Due','Status']
  const rows=orders.map(o=>[o.invoiceNo,o.date,o.customer.name,o.customer.phone,o.customer.address,o.items.map(i=>`${i.name} ${i.size} x${i.qty}`).join('; '),subtotal(o),o.delivery,o.discount,grand(o),paid(o),due(o),status(o)])
  return '\ufeff'+[h,...rows].map(r=>r.map(esc).join(',')).join('\n')
}
export const readLogo=(f:File)=>new Promise<string>(res=>{const r=new FileReader();r.onload=()=>{const i=new Image();i.onload=()=>{const m=Math.min(1,300/Math.max(i.width,i.height));const c=document.createElement('canvas');c.width=i.width*m;c.height=i.height*m;c.getContext('2d')!.drawImage(i,0,0,c.width,c.height);res(c.toDataURL('image/png'))};i.src=r.result as string};r.readAsDataURL(f)})

// PDF: render invoice DOM to canvas (browser shapes Bengali correctly) -> jsPDF
export async function makePdf(el:HTMLElement){
  const [{default:html2canvas},{jsPDF}]=await Promise.all([import('html2canvas'),import('jspdf')])
  const c=await html2canvas(el,{scale:2,backgroundColor:'#ffffff',useCORS:true})
  const w=210,h=c.height*w/c.width
  const pdf=new jsPDF({unit:'mm',format:h>297?[w,h]:'a4'})
  pdf.addImage(c.toDataURL('image/jpeg',0.95),'JPEG',0,0,w,h)
  return pdf
}
