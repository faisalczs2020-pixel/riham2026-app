import {useEffect,useMemo,useRef,useState} from 'react'
import {createPortal} from 'react-dom'
import {Download,Printer,Share2,Plus,Trash2,Pencil,Search,Upload,FilePlus,Ban,RotateCcw,FileDown,Save} from 'lucide-react'
import type {Customer,DB,Item,Method,Order,Page,Product} from './types'
import {METHODS} from './types'
import {Btn,Card,Field,H,Modal,Badge,inp,cx} from './ui'
import {Invoice} from './Invoice'
import {uid,money,today,fmtDate,sub,grand,paid,due,status,subtotal,download,ordersCsv,readLogo,makePdf,normalize,markBackup,lastBackup} from './lib'

type SetDB=React.Dispatch<React.SetStateAction<DB>>
const num=(v:string)=>Number(v)||0

/* ---------- shared ---------- */
function OrderRow({o,open}:{o:Order;open:(id:string)=>void}){
  return <button onClick={()=>open(o.id)} className="w-full text-left rounded-2xl bg-white p-3 border border-ink/5 shadow-sm">
    <div className="flex justify-between gap-2"><div className="min-w-0"><div className="font-semibold text-sm truncate">{o.customer.name}</div><div className="text-xs text-ink/50">{o.invoiceNo} · {fmtDate(o.date)}</div></div>
    <div className="text-right"><div className="font-semibold text-sm">{money(grand(o))}</div><Badge s={status(o)}/></div></div>
    {!o.cancelled&&due(o)>0&&<div className="text-xs text-red-600 mt-1">Due {money(due(o))}</div>}</button>
}

/* ---------- Dashboard ---------- */
export function Dashboard({db,open,go}:{db:DB;open:(id:string)=>void;go:(p:Page)=>void}){
  const act=db.orders.filter(o=>!o.cancelled)
  const st=[['Total Orders',String(act.length)],['Total Sales',money(act.reduce((a,o)=>a+grand(o),0))],['Payments Received',money(act.reduce((a,o)=>a+paid(o),0))],['Outstanding Dues',money(act.reduce((a,o)=>a+due(o),0))]]
  const stale=db.orders.length>0&&Date.now()-lastBackup()>7*864e5
  return <div>
    <H right={<Btn onClick={()=>go('new')}><Plus size={16}/>New Order</Btn>}>Dashboard</H>
    {stale&&<div className="mb-3 rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-800">No backup in the last 7 days. Your data lives only in this browser — go to Settings → Download Backup.</div>}
    <div className="grid grid-cols-2 gap-3 mb-5">{st.map(([l,v],i)=><Card key={l} className={i===3?'bg-ink text-gold':''}><div className={cx('text-xs',i===3?'text-white/60':'text-ink/50')}>{l}</div><div className="text-xl font-bold mt-1">{v}</div></Card>)}</div>
    <h3 className="font-semibold mb-2">Recent Orders</h3>
    <div className="space-y-2">{db.orders.slice(0,5).map(o=><OrderRow key={o.id} o={o} open={open}/>)}{!db.orders.length&&<p className="text-sm text-ink/50">No orders yet. Add products, then create your first order.</p>}</div>
  </div>
}

/* ---------- New / Edit Order ---------- */
const blank=():Item=>({productId:'',name:'',size:'',qty:1,price:0})
export function NewOrder({db,setDb,editing,onSaved,onCancel}:{db:DB;setDb:SetDB;editing?:Order;onSaved:(id:string)=>void;onCancel?:()=>void}){
  const s=db.settings
  const [cust,setCust]=useState<Customer>(editing?.customer??{id:'',name:'',phone:'',address:''})
  const [items,setItems]=useState<Item[]>(editing?.items??[blank()])
  const [delivery,setDelivery]=useState(editing?.delivery??s.delivery)
  const [discount,setDiscount]=useState(editing?.discount??0)
  const [advance,setAdvance]=useState(0)
  const [method,setMethod]=useState<Method>('Cash')
  const [date,setDate]=useState(editing?.date??today())
  const gt=sub(items)+delivery-discount
  const setItem=(k:number,p:Partial<Item>)=>setItems(a=>a.map((x,i)=>i===k?{...x,...p}:x))
  const pick=(k:number,pid:string)=>{const p=db.products.find(x=>x.id===pid);setItem(k,p?{productId:p.id,name:p.name,size:p.size,price:p.price}:{productId:'',name:'',size:''})}
  const save=()=>{
    if(!cust.name.trim())return alert('Customer name is required')
    const its=items.filter(i=>i.qty>0&&i.name.trim())
    if(!its.length)return alert('Add at least one product with quantity')
    if(gt<0)return alert('Discount cannot exceed the total')
    if(!editing&&advance>gt)return alert('Advance cannot exceed Grand Total')
    if(editing&&!confirm(`Save changes to ${editing.invoiceNo}? The previous version will be replaced.`))return
    const c={...cust,name:cust.name.trim(),phone:cust.phone.trim(),address:cust.address.trim()}
    const found=db.customers.find(x=>x.id===c.id||(c.phone&&x.phone===c.phone))
    const newC=found?null:{...c,id:uid()}
    c.id=found?.id??newC!.id
    const now=Date.now()
    if(editing){
      const o:Order={...editing,date,customer:c,items:its,delivery,discount,updatedAt:now}
      setDb(d=>({...d,customers:newC?[newC,...d.customers]:d.customers,orders:d.orders.map(x=>x.id===o.id?o:x)}));return onSaved(o.id)
    }
    let n=s.counter;const no=()=>`${s.prefix}-${String(n).padStart(4,'0')}`
    while(db.orders.some(o=>o.invoiceNo===no()))n++
    const o:Order={id:uid(),invoiceNo:no(),date,customer:c,items:its,delivery,discount,createdAt:now,updatedAt:now,
      payments:advance>0?[{id:uid(),date,amount:advance,method}]:[]}
    setDb(d=>({...d,customers:newC?[newC,...d.customers]:d.customers,orders:[o,...d.orders],settings:{...d.settings,counter:n+1}}))
    onSaved(o.id)
  }
  return <div>
    <H>{editing?`Edit ${editing.invoiceNo}`:'New Order'}</H>
    <Card className="mb-3">
      <Field label="Saved customer (optional)"><select className={inp} value={cust.id} onChange={e=>{const c=db.customers.find(x=>x.id===e.target.value);setCust(c??{id:'',name:'',phone:'',address:''})}}>
        <option value="">+ New customer</option>{db.customers.map(c=><option key={c.id} value={c.id}>{c.name} {c.phone}</option>)}</select></Field>
      <Field label="Customer Name"><input className={inp} value={cust.name} onChange={e=>setCust({...cust,name:e.target.value})}/></Field>
      <Field label="Mobile Number"><input className={inp} inputMode="tel" value={cust.phone} onChange={e=>setCust({...cust,phone:e.target.value})}/></Field>
      <Field label="Delivery Address"><textarea className={inp} rows={2} value={cust.address} onChange={e=>setCust({...cust,address:e.target.value})}/></Field>
      <Field label="Order Date"><input type="date" className={inp} value={date} onChange={e=>setDate(e.target.value)}/></Field>
    </Card>
    <Card className="mb-3">
      <h3 className="font-semibold mb-3">Products</h3>
      {items.map((it,k)=><div key={k} className="mb-4 pb-4 border-b border-ink/10 last:border-0">
        <select className={inp+' mb-2'} value={it.productId} onChange={e=>pick(k,e.target.value)}><option value="">Custom item…</option>{db.products.map(p=><option key={p.id} value={p.id}>{p.name} {p.size} — {money(p.price)}</option>)}</select>
        {!it.productId&&<div className="grid grid-cols-3 gap-2 mb-2"><input className={inp+' col-span-2'} placeholder="Perfume name" value={it.name} onChange={e=>setItem(k,{name:e.target.value})}/><input className={inp} placeholder="Size" value={it.size} onChange={e=>setItem(k,{size:e.target.value})}/></div>}
        <div className="grid grid-cols-3 gap-2 items-end">
          <label className="text-[10px] text-ink/50">Qty<input type="number" min={1} inputMode="numeric" className={inp} value={it.qty||''} onChange={e=>setItem(k,{qty:num(e.target.value)})}/></label>
          <label className="text-[10px] text-ink/50">Unit Price<input type="number" min={0} inputMode="decimal" className={inp} value={it.price||''} onChange={e=>setItem(k,{price:num(e.target.value)})}/></label>
          <div className="text-right text-sm font-semibold pb-2">{money(it.qty*it.price)}{items.length>1&&<button className="ml-2 text-red-500 align-middle" onClick={()=>setItems(a=>a.filter((_,i)=>i!==k))}><Trash2 size={15}/></button>}</div>
        </div></div>)}
      <Btn v="line" onClick={()=>setItems(a=>[...a,blank()])}><Plus size={16}/>Add Product</Btn>
    </Card>
    <Card className="mb-4">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Delivery Charge"><input type="number" inputMode="decimal" className={inp} value={delivery||''} onChange={e=>setDelivery(num(e.target.value))}/></Field>
        <Field label="Discount"><input type="number" inputMode="decimal" className={inp} value={discount||''} onChange={e=>setDiscount(num(e.target.value))}/></Field>
        {!editing&&<><Field label="Advance Payment"><input type="number" inputMode="decimal" className={inp} value={advance||''} onChange={e=>setAdvance(num(e.target.value))}/></Field>
        <Field label="Method"><select className={inp} value={method} onChange={e=>setMethod(e.target.value as Method)}>{METHODS.map(m=><option key={m}>{m}</option>)}</select></Field></>}
      </div>
      <div className="text-sm space-y-1">
        <div className="flex justify-between"><span>Subtotal</span><b>{money(sub(items))}</b></div>
        <div className="flex justify-between text-base"><span>Grand Total</span><b>{money(gt)}</b></div>
        {editing?<div className="flex justify-between text-xs text-ink/50"><span>Already paid</span><span>{money(paid(editing))}</span></div>
        :<div className="flex justify-between text-red-600"><span>Remaining Due</span><b>{money(Math.max(0,gt-advance))}</b></div>}
      </div>
    </Card>
    <div className="flex gap-2"><Btn className="flex-1" onClick={save}><FilePlus size={16}/>{editing?'Save & View Cash Memo':'Generate Cash Memo'}</Btn>{onCancel&&<Btn v="line" onClick={onCancel}>Cancel</Btn>}</div>
  </div>
}

/* ---------- Invoice view + payments ---------- */
export function InvoiceView({db,setDb,id,back,edit,newOrder}:{db:DB;setDb:SetDB;id:string;back:()=>void;edit:(o:Order)=>void;newOrder:()=>void}){
  const o=db.orders.find(x=>x.id===id)
  const ref=useRef<HTMLDivElement>(null)
  const [zm,setZm]=useState(1)
  const [busy,setBusy]=useState(false)
  const [pay,setPay]=useState<{amount:number;method:Method;date:string}>({amount:0,method:'Cash',date:today()})
  useEffect(()=>{const f=()=>setZm(Math.min(1,(Math.min(window.innerWidth,896)-32)/794));f();window.addEventListener('resize',f);return()=>window.removeEventListener('resize',f)},[])
  if(!o)return null
  const s=db.settings
  const upd=(f:(x:Order)=>Order)=>setDb(d=>({...d,orders:d.orders.map(x=>x.id===id?{...f(x),updatedAt:Date.now()}:x)}))
  const mk=async()=>{setBusy(true);try{await document.fonts?.ready;return await makePdf(ref.current!)}catch{alert('PDF generation failed. Please try again.');return null}finally{setBusy(false)}}
  const dl=async()=>{const p=await mk();p?.save(`${o.invoiceNo}.pdf`)}
  const share=async()=>{const p=await mk();if(!p)return
    const f=new File([p.output('blob')],`${o.invoiceNo}.pdf`,{type:'application/pdf'})
    try{if(navigator.canShare?.({files:[f]}))await navigator.share({files:[f],title:`${s.name} ${o.invoiceNo}`});else{p.save(f.name);alert('Sharing is not supported on this device — the PDF was downloaded instead.')}}
    catch(e){if((e as Error).name!=='AbortError')alert('Share failed')}}
  const addPay=()=>{const d=due(o);if(pay.amount<=0)return alert('Enter an amount');if(pay.amount>d)return alert(`Amount exceeds remaining due (${money(d)})`)
    upd(x=>({...x,payments:[...x.payments,{id:uid(),...pay}]}));setPay({...pay,amount:0})}
  return <div>
    <button onClick={back} className="text-sm text-ink/60 mb-2">← Back</button>
    <div className="grid grid-cols-2 gap-2 mb-3">
      <Btn onClick={dl} disabled={busy}><Download size={16}/>{busy?'Preparing…':'Download PDF'}</Btn>
      <Btn v="dark" onClick={()=>window.print()}><Printer size={16}/>Print</Btn>
      <Btn v="line" onClick={share} disabled={busy}><Share2 size={16}/>Share</Btn>
      <Btn v="line" onClick={newOrder}><Plus size={16}/>Create New Order</Btn>
    </div>
    <div className="mx-auto shadow-xl overflow-hidden mb-4" style={{width:794*zm}}><div style={{zoom:zm}}><Invoice o={o} s={s}/></div></div>
    {createPortal(<div id="print-area" style={{position:'fixed',left:-10000,top:0}}><Invoice ref={ref} o={o} s={s}/></div>,document.body)}
    <Card className="mb-3">
      <h3 className="font-semibold mb-2">Payments · Due {money(due(o))}</h3>
      {o.payments.map(p=><div key={p.id} className="flex justify-between text-sm py-1 border-b border-ink/5"><span>{fmtDate(p.date)} · {p.method}</span>
        <span>{money(p.amount)} <button className="text-red-500 ml-2" onClick={()=>confirm('Remove this payment?')&&upd(x=>({...x,payments:x.payments.filter(y=>y.id!==p.id)}))}><Trash2 size={14}/></button></span></div>)}
      {!o.cancelled&&due(o)>0&&<div className="grid grid-cols-3 gap-2 mt-3">
        <input type="number" inputMode="decimal" placeholder="Amount" className={inp} value={pay.amount||''} onChange={e=>setPay({...pay,amount:num(e.target.value)})}/>
        <select className={inp} value={pay.method} onChange={e=>setPay({...pay,method:e.target.value as Method})}>{METHODS.map(m=><option key={m}>{m}</option>)}</select>
        <input type="date" className={inp} value={pay.date} onChange={e=>setPay({...pay,date:e.target.value})}/>
        <Btn className="col-span-3" onClick={addPay}>Add Payment</Btn></div>}
    </Card>
    <div className="grid grid-cols-3 gap-2">
      <Btn v="line" onClick={()=>edit(o)}><Pencil size={15}/>Edit</Btn>
      <Btn v="line" onClick={()=>{if(confirm(o.cancelled?'Restore this order?':'Cancel this order? It will be excluded from sales totals.'))upd(x=>({...x,cancelled:!x.cancelled}))}}>{o.cancelled?<><RotateCcw size={15}/>Restore</>:<><Ban size={15}/>Cancel</>}</Btn>
      <Btn v="red" onClick={()=>{if(confirm(`Permanently delete ${o.invoiceNo}? This cannot be undone.`)){setDb(d=>({...d,orders:d.orders.filter(x=>x.id!==id)}));back()}}}><Trash2 size={15}/>Delete</Btn>
    </div>
  </div>
}

/* ---------- Orders ---------- */
export function Orders({db,open}:{db:DB;open:(id:string)=>void}){
  const [q,setQ]=useState(''),[st,setSt]=useState('All'),[from,setFrom]=useState(''),[to,setTo]=useState('')
  const list=db.orders.filter(o=>{const t=q.toLowerCase();return (!t||(o.customer.name+o.customer.phone+o.invoiceNo).toLowerCase().includes(t))&&(st==='All'||status(o)===st)&&(!from||o.date>=from)&&(!to||o.date<=to)})
  return <div>
    <H right={<Btn v="line" onClick={()=>download(`riham-orders-${today()}.csv`,ordersCsv(list),'text/csv')}><FileDown size={16}/>CSV</Btn>}>Orders ({list.length})</H>
    <div className="relative mb-2"><Search size={16} className="absolute left-3 top-3 text-ink/40"/><input className={inp+' pl-9'} placeholder="Search name, phone or Order ID" value={q} onChange={e=>setQ(e.target.value)}/></div>
    <div className="grid grid-cols-3 gap-2 mb-3"><select className={inp} value={st} onChange={e=>setSt(e.target.value)}>{['All','Paid','Partial','Unpaid','Cancelled'].map(x=><option key={x}>{x}</option>)}</select>
      <input type="date" className={inp} value={from} onChange={e=>setFrom(e.target.value)}/><input type="date" className={inp} value={to} onChange={e=>setTo(e.target.value)}/></div>
    <div className="space-y-2">{list.map(o=><OrderRow key={o.id} o={o} open={open}/>)}{!list.length&&<p className="text-sm text-ink/50">No orders found.</p>}</div>
  </div>
}

/* ---------- Customers ---------- */
export function Customers({db,setDb,open}:{db:DB;setDb:SetDB;open:(id:string)=>void}){
  const [q,setQ]=useState(''),[ed,setEd]=useState<Customer|null>(null),[exp,setExp]=useState('')
  const list=db.customers.filter(c=>(c.name+c.phone).toLowerCase().includes(q.toLowerCase()))
  const save=()=>{if(!ed||!ed.name.trim())return alert('Name is required')
    setDb(d=>({...d,customers:d.customers.some(c=>c.id===ed.id)?d.customers.map(c=>c.id===ed.id?ed:c):[ed,...d.customers]}));setEd(null)}
  return <div>
    <H right={<Btn onClick={()=>setEd({id:uid(),name:'',phone:'',address:''})}><Plus size={16}/>Add</Btn>}>Customers ({db.customers.length})</H>
    <div className="relative mb-3"><Search size={16} className="absolute left-3 top-3 text-ink/40"/><input className={inp+' pl-9'} placeholder="Search name or phone" value={q} onChange={e=>setQ(e.target.value)}/></div>
    <div className="space-y-2">{list.map(c=>{const hist=db.orders.filter(o=>o.customer.id===c.id||(c.phone&&o.customer.phone===c.phone))
      return <Card key={c.id}><div className="flex justify-between"><button className="text-left" onClick={()=>setExp(exp===c.id?'':c.id)}><div className="font-semibold text-sm">{c.name}</div><div className="text-xs text-ink/50">{c.phone} · {hist.length} orders</div></button>
        <button onClick={()=>setEd(c)}><Pencil size={16}/></button></div>
        {exp===c.id&&<div className="mt-3 space-y-2"><div className="text-xs text-ink/60">{c.address}</div>{hist.map(o=><OrderRow key={o.id} o={o} open={open}/>)}{!hist.length&&<div className="text-xs text-ink/50">No orders yet.</div>}</div>}</Card>})}
      {!list.length&&<p className="text-sm text-ink/50">No customers found.</p>}</div>
    {ed&&<Modal title="Customer" onClose={()=>setEd(null)}>
      <Field label="Name"><input className={inp} value={ed.name} onChange={e=>setEd({...ed,name:e.target.value})}/></Field>
      <Field label="Mobile"><input className={inp} inputMode="tel" value={ed.phone} onChange={e=>setEd({...ed,phone:e.target.value})}/></Field>
      <Field label="Delivery Address"><textarea className={inp} rows={3} value={ed.address} onChange={e=>setEd({...ed,address:e.target.value})}/></Field>
      <p className="text-[11px] text-ink/50 mb-3">Past invoices keep the details they were issued with.</p>
      <Btn className="w-full" onClick={save}><Save size={16}/>Save</Btn></Modal>}
  </div>
}

/* ---------- Products ---------- */
export function Products({db,setDb}:{db:DB;setDb:SetDB}){
  const [ed,setEd]=useState<Product|null>(null)
  const save=()=>{if(!ed||!ed.name.trim())return alert('Perfume name is required')
    setDb(d=>({...d,products:d.products.some(p=>p.id===ed.id)?d.products.map(p=>p.id===ed.id?ed:p):[...d.products,ed]}));setEd(null)}
  return <div>
    <H right={<Btn onClick={()=>setEd({id:uid(),name:'',size:'50ml',price:0})}><Plus size={16}/>Add</Btn>}>Products ({db.products.length})</H>
    <div className="space-y-2">{db.products.map(p=><Card key={p.id}><div className="flex justify-between items-center"><div><div className="font-semibold text-sm">{p.name}</div><div className="text-xs text-ink/50">{p.size}</div></div>
      <div className="flex items-center gap-3"><b className="text-sm">{money(p.price)}</b><button onClick={()=>setEd(p)}><Pencil size={16}/></button>
      <button className="text-red-500" onClick={()=>confirm(`Delete ${p.name}? Existing orders are not affected.`)&&setDb(d=>({...d,products:d.products.filter(x=>x.id!==p.id)}))}><Trash2 size={16}/></button></div></div></Card>)}
      {!db.products.length&&<p className="text-sm text-ink/50">No products yet — add your perfumes here, then pick them in New Order.</p>}</div>
    {ed&&<Modal title="Product" onClose={()=>setEd(null)}>
      <Field label="Perfume Name"><input className={inp} value={ed.name} onChange={e=>setEd({...ed,name:e.target.value})}/></Field>
      <Field label="Size"><input className={inp} list="sizes" value={ed.size} onChange={e=>setEd({...ed,size:e.target.value})}/><datalist id="sizes"><option value="30ml"/><option value="50ml"/><option value="100ml"/></datalist></Field>
      <Field label="Selling Price (৳)"><input type="number" inputMode="decimal" className={inp} value={ed.price||''} onChange={e=>setEd({...ed,price:num(e.target.value)})}/></Field>
      <Btn className="w-full" onClick={save}><Save size={16}/>Save</Btn></Modal>}
  </div>
}

/* ---------- Reports ---------- */
export function Reports({db}:{db:DB}){
  const [m,setM]=useState<'day'|'month'>('day')
  const L=m==='day'?10:7
  const act=db.orders.filter(o=>!o.cancelled)
  const rows=useMemo(()=>{const r:Record<string,{n:number;s:number;p:number}>={};const g=(k:string)=>(r[k]??={n:0,s:0,p:0})
    act.forEach(o=>{const a=g(o.date.slice(0,L));a.n++;a.s+=grand(o);o.payments.forEach(p=>{g(p.date.slice(0,L)).p+=p.amount})})
    return Object.entries(r).sort((a,b)=>b[0].localeCompare(a[0]))},[db.orders,m])
  const byM=METHODS.map(k=>[k,act.reduce((a,o)=>a+o.payments.filter(p=>p.method===k).reduce((x,p)=>x+p.amount,0),0)] as const)
  return <div>
    <H right={<Btn v="line" onClick={()=>download(`riham-orders-${today()}.csv`,ordersCsv(db.orders),'text/csv')}><FileDown size={16}/>Export CSV</Btn>}>Reports</H>
    <p className="text-xs text-ink/50 mb-3">Cancelled orders are excluded.</p>
    <Card className="mb-3"><h3 className="font-semibold mb-2 text-sm">Received by method</h3><div className="grid grid-cols-2 gap-2 text-sm">{byM.map(([k,v])=><div key={k} className="flex justify-between"><span>{k}</span><b>{money(v)}</b></div>)}</div></Card>
    <div className="flex gap-2 mb-3">{(['day','month'] as const).map(x=><Btn key={x} v={m===x?'dark':'line'} onClick={()=>setM(x)}>{x==='day'?'Daily':'Monthly'}</Btn>)}</div>
    <Card className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left text-xs text-ink/50"><th className="pb-2">{m==='day'?'Date':'Month'}</th><th>Orders</th><th className="text-right">Sales</th><th className="text-right">Received</th></tr></thead>
      <tbody>{rows.map(([k,v])=><tr key={k} className="border-t border-ink/5"><td className="py-2">{m==='day'?fmtDate(k):k}</td><td>{v.n}</td><td className="text-right">{money(v.s)}</td><td className="text-right">{money(v.p)}</td></tr>)}</tbody></table>
      {!rows.length&&<p className="text-sm text-ink/50">No data yet.</p>}</Card>
  </div>
}

/* ---------- Settings ---------- */
export function SettingsPage({db,setDb}:{db:DB;setDb:SetDB}){
  const [s,setS]=useState(db.settings)
  const [lb,setLb]=useState(lastBackup())
  const set=(k:string,v:string|number)=>setS(p=>({...p,[k]:v}))
  const t=(k:'name'|'tagline'|'phone'|'facebook'|'address'|'prefix',l:string)=><Field label={l}><input className={inp} value={s[k]} onChange={e=>set(k,e.target.value)}/></Field>
  const backup=()=>{download(`riham-backup-${today()}.json`,JSON.stringify(db),'application/json');markBackup();setLb(Date.now())}
  const restore=async(f?:File)=>{if(!f)return
    try{const x=JSON.parse(await f.text());if(!Array.isArray(x.orders)||!Array.isArray(x.customers)||!Array.isArray(x.products))throw 0
      if(confirm(`Restore backup with ${x.orders.length} orders, ${x.customers.length} customers, ${x.products.length} products?\n\nThis REPLACES all data currently on this device. Download a backup first if unsure.`)){setDb(normalize(x));setS(normalize(x).settings)}}
    catch{alert('Invalid backup file.')}}
  return <div>
    <H>Settings</H>
    <Card className="mb-3">
      <Field label="Brand Logo"><div className="flex items-center gap-3"><img src={s.logo} className="h-14 w-14 rounded-lg object-cover bg-ink"/>
        <label className="text-sm font-semibold border border-ink/20 rounded-xl px-3 py-2 bg-white cursor-pointer">Upload<input type="file" accept="image/*" hidden onChange={async e=>{const f=e.target.files?.[0];if(f)set('logo',await readLogo(f))}}/></label>
        <button className="text-xs text-ink/50" onClick={()=>set('logo','/logo.jpg')}>Reset</button></div></Field>
      {t('name','Business Name')}{t('tagline','Tagline')}{t('phone','Phone Number')}{t('facebook','Facebook Page')}{t('address','Business Address')}
      <div className="grid grid-cols-3 gap-2"><Field label="Default Delivery ৳"><input type="number" className={inp} value={s.delivery||''} onChange={e=>set('delivery',num(e.target.value))}/></Field>
        {t('prefix','Invoice Prefix')}<Field label="Next Invoice #"><input type="number" className={inp} value={s.counter} onChange={e=>set('counter',Math.max(1,num(e.target.value)))}/></Field></div>
      <Btn className="w-full" onClick={()=>{setDb(d=>({...d,settings:s}));alert('Settings saved')}}><Save size={16}/>Save Settings</Btn>
    </Card>
    <Card>
      <h3 className="font-semibold mb-1">Data Safety</h3>
      <p className="text-xs text-ink/60 mb-3">Your data is stored only in this browser on this device (LocalStorage). Clearing browser data, switching phones/browsers or using private mode will not carry it over. Download backups regularly{lb?` — last backup: ${new Date(lb).toLocaleString()}`:' — no backup yet'}.</p>
      <div className="grid grid-cols-2 gap-2">
        <Btn onClick={backup}><Download size={16}/>Download Backup</Btn>
        <label className="inline-flex items-center justify-center gap-2 rounded-xl border border-ink/20 bg-white px-4 py-2.5 text-sm font-semibold cursor-pointer"><Upload size={16}/>Restore<input type="file" accept="application/json,.json" hidden onChange={e=>{restore(e.target.files?.[0]);e.target.value=''}}/></label>
        <Btn v="line" className="col-span-2" onClick={()=>download(`riham-orders-${today()}.csv`,ordersCsv(db.orders),'text/csv')}><FileDown size={16}/>Export Orders CSV</Btn>
        <Btn v="red" className="col-span-2" onClick={()=>{if(confirm('Delete ALL orders, customers and products from this device?')&&confirm('Are you absolutely sure? This cannot be undone unless you have a backup.'))setDb(d=>({...d,orders:[],customers:[],products:[],settings:{...d.settings,counter:1}}))}}><Trash2 size={16}/>Erase All Data</Btn>
      </div>
    </Card>
  </div>
}
