import {useState} from 'react'
import {LayoutDashboard,PlusCircle,ClipboardList,Users,Package,BarChart3,Settings as Cog} from 'lucide-react'
import {useDB,uid} from './lib'
import type {Page,Order} from './types'
import {cx} from './ui'
import {Dashboard,NewOrder,InvoiceView,Orders,Customers,Products,Reports,SettingsPage} from './pages'

const NAV:[Page,string,typeof Cog][]=[['dash','Dashboard',LayoutDashboard],['new','New Order',PlusCircle],['orders','Orders',ClipboardList],['customers','Customers',Users],['products','Products',Package],['reports','Reports',BarChart3],['settings','Settings',Cog]]
export default function App(){
  const [db,setDb]=useDB()
  const [page,setPage]=useState<Page>('dash')
  const [view,setView]=useState<string|null>(null)
  const [edit,setEdit]=useState<Order|null>(null)
  const [nk,setNk]=useState(uid())
  const go=(p:Page)=>{setPage(p);setView(null);setEdit(null);if(p==='new')setNk(uid())}
  const s=db.settings
  return <div className="min-h-screen pb-24">
    <header className="sticky top-0 z-40 bg-ink text-white px-4 py-3 flex items-center gap-3" style={{paddingTop:'max(0.75rem,env(safe-area-inset-top))'}}>
      <img src={s.logo} className="h-9 w-9 rounded-lg object-cover"/>
      <div><div className="text-gold font-semibold tracking-[0.25em] leading-none">{s.name}</div><div className="text-[8px] tracking-widest text-white/60 mt-1">{s.tagline}</div></div>
    </header>
    <main className="mx-auto max-w-4xl p-4">
      {view?<InvoiceView db={db} setDb={setDb} id={view} back={()=>setView(null)} edit={o=>{setEdit(o);setView(null)}} newOrder={()=>go('new')}/>
      :edit?<NewOrder key={edit.id} db={db} setDb={setDb} editing={edit} onSaved={id=>{setEdit(null);setView(id)}} onCancel={()=>{setView(edit.id);setEdit(null)}}/>
      :page==='dash'?<Dashboard db={db} open={setView} go={go}/>
      :page==='new'?<NewOrder key={nk} db={db} setDb={setDb} onSaved={setView}/>
      :page==='orders'?<Orders db={db} open={setView}/>
      :page==='customers'?<Customers db={db} setDb={setDb} open={setView}/>
      :page==='products'?<Products db={db} setDb={setDb}/>
      :page==='reports'?<Reports db={db}/>
      :<SettingsPage db={db} setDb={setDb}/>}
    </main>
    <nav className="fixed bottom-0 inset-x-0 z-40 bg-ink border-t border-white/10 flex justify-around" style={{paddingBottom:'env(safe-area-inset-bottom)'}}>
      {NAV.map(([p,l,I])=><button key={p} onClick={()=>go(p)} className={cx('flex-1 flex flex-col items-center gap-0.5 py-2 text-[9px]',page===p&&!view&&!edit?'text-gold':'text-white/60')}><I size={20}/>{l}</button>)}
    </nav>
  </div>
}
