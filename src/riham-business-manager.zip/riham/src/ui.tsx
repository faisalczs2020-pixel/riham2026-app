import {ReactNode,ButtonHTMLAttributes} from 'react'
import {X} from 'lucide-react'
export const cx=(...a:(string|false|undefined)[])=>a.filter(Boolean).join(' ')
export const inp='w-full rounded-xl border border-ink/15 bg-white px-3 py-2.5 text-sm text-ink outline-none focus:border-gold'
export function Btn({v='gold',className,...p}:ButtonHTMLAttributes<HTMLButtonElement>&{v?:'gold'|'dark'|'line'|'red'}){
  const s={gold:'bg-gold text-ink',dark:'bg-ink text-white',line:'border border-ink/20 bg-white text-ink',red:'bg-red-600 text-white'}[v]
  return <button {...p} className={cx('inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold active:scale-95 transition disabled:opacity-50',s,className)}/>
}
export const Card=({children,className}:{children:ReactNode;className?:string})=><div className={cx('rounded-2xl bg-white p-4 shadow-sm border border-ink/5',className)}>{children}</div>
export const Field=({label,children}:{label:string;children:ReactNode})=><label className="block text-xs font-medium text-ink/60 mb-3">{label}<div className="mt-1">{children}</div></label>
export const H=({children,right}:{children:ReactNode;right?:ReactNode})=><div className="flex items-center justify-between mb-3"><h2 className="text-lg font-semibold">{children}</h2>{right}</div>
export function Modal({title,onClose,children}:{title:string;onClose:()=>void;children:ReactNode}){
  return <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4">
    <div className="w-full max-w-md max-h-[90vh] overflow-auto rounded-t-3xl sm:rounded-3xl bg-cream p-5">
      <div className="flex justify-between items-center mb-4"><h3 className="font-semibold text-lg">{title}</h3><button onClick={onClose}><X size={20}/></button></div>{children}</div></div>
}
export function Badge({s}:{s:string}){
  const c:Record<string,string>={Paid:'bg-green-100 text-green-700',Partial:'bg-amber-100 text-amber-700',Unpaid:'bg-red-100 text-red-700',Cancelled:'bg-gray-200 text-gray-600'}
  return <span className={cx('inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase',c[s])}>{s}</span>
}
