import {forwardRef} from 'react'
import type {Order,Settings} from './types'
import {money,fmtDate,subtotal,grand,paid,due,status} from './lib'

const gold='#C9A55C'
export const Invoice=forwardRef<HTMLDivElement,{o:Order;s:Settings}>(({o,s},ref)=>{
  const st=status(o)
  const stc:Record<string,string>={Paid:'#15803d',Partial:'#b45309',Unpaid:'#b91c1c',Cancelled:'#6b7280'}
  const row=(l:string,v:string,bold?:boolean)=><div style={{display:'flex',justifyContent:'space-between',padding:'6px 0',fontWeight:bold?700:400,fontSize:bold?16:13}}><span>{l}</span><span>{v}</span></div>
  return <div ref={ref} style={{width:794,minHeight:1123,background:'#fff',color:'#111',display:'flex',flexDirection:'column',fontFamily:"'Inter','Noto Sans Bengali',sans-serif"}}>
    <div style={{background:'#111',color:'#fff',padding:'32px 40px',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
      <div style={{display:'flex',alignItems:'center',gap:20}}>
        <img src={s.logo} crossOrigin="anonymous" style={{width:80,height:80,borderRadius:12,objectFit:'cover'}}/>
        <div><div style={{fontFamily:"'Cormorant Garamond',serif",fontWeight:600,fontSize:40,letterSpacing:'0.3em',color:gold,lineHeight:1}}>{s.name}</div>
        <div style={{fontSize:10,letterSpacing:'0.2em',marginTop:10,color:'rgba(255,255,255,.7)'}}>{s.tagline}</div></div>
      </div>
      <div style={{textAlign:'right'}}><div style={{color:gold,fontSize:14,letterSpacing:'0.3em'}}>CASH MEMO</div>
        <div style={{marginTop:8,fontSize:14,fontWeight:600}}>{o.invoiceNo}</div><div style={{fontSize:12,color:'rgba(255,255,255,.7)'}}>{fmtDate(o.date)}</div></div>
    </div>
    <div style={{height:4,background:gold}}/>
    <div style={{padding:'28px 40px',flex:1}}>
      <div style={{display:'flex',justifyContent:'space-between',marginBottom:24}}>
        <div><div style={{fontSize:10,letterSpacing:'0.2em',color:gold,fontWeight:600}}>BILLED TO</div>
          <div style={{fontSize:18,fontWeight:600,marginTop:6}}>{o.customer.name}</div>
          <div style={{fontSize:13,marginTop:4}}>{o.customer.phone}</div>
          <div style={{fontSize:13,marginTop:2,maxWidth:380,color:'#444'}}>{o.customer.address}</div></div>
        <div style={{textAlign:'right'}}><div style={{fontSize:10,letterSpacing:'0.2em',color:gold,fontWeight:600}}>PAYMENT STATUS</div>
          <div style={{marginTop:8,display:'inline-block',border:`2px solid ${stc[st]}`,color:stc[st],borderRadius:8,padding:'4px 14px',fontWeight:700,fontSize:14,letterSpacing:'0.1em'}}>{st.toUpperCase()}</div></div>
      </div>
      <table style={{width:'100%',borderCollapse:'collapse',fontSize:13}}>
        <thead><tr style={{background:'#F7F1E3',color:'#111',textAlign:'left'}}>{['#','Product','Size','Qty','Unit Price','Total'].map((h,i)=><th key={h} style={{padding:'10px 8px',fontSize:11,letterSpacing:'0.08em',textAlign:i>2?'right':'left'}}>{h}</th>)}</tr></thead>
        <tbody>{o.items.map((i,k)=><tr key={k} style={{borderBottom:'1px solid #eee'}}>
          <td style={{padding:'10px 8px'}}>{k+1}</td><td style={{padding:'10px 8px',fontWeight:500}}>{i.name}</td><td style={{padding:'10px 8px'}}>{i.size}</td>
          <td style={{padding:'10px 8px',textAlign:'right'}}>{i.qty}</td><td style={{padding:'10px 8px',textAlign:'right'}}>{money(i.price)}</td><td style={{padding:'10px 8px',textAlign:'right',fontWeight:600}}>{money(i.qty*i.price)}</td></tr>)}</tbody>
      </table>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginTop:24,gap:30}}>
        <div style={{flex:1,fontSize:12}}>{o.payments.length>0&&<><div style={{fontSize:10,letterSpacing:'0.2em',color:gold,fontWeight:600,marginBottom:6}}>PAYMENTS</div>
          {o.payments.map(p=><div key={p.id} style={{padding:'3px 0',color:'#444'}}>{fmtDate(p.date)} · {p.method} · {money(p.amount)}</div>)}</>}</div>
        <div style={{width:300}}>
          {row('Subtotal',money(subtotal(o)))}{row('Delivery Charge',money(o.delivery))}{row('Discount','- '+money(o.discount))}
          <div style={{borderTop:`2px solid ${gold}`,marginTop:4}}/>{row('Grand Total',money(grand(o)),true)}
          {row('Advance / Paid',money(paid(o)))}
          <div style={{background:'#111',color:gold,borderRadius:8,padding:'0 12px',marginTop:6}}>{row('Remaining Due',money(due(o)),true)}</div>
        </div>
      </div>
    </div>
    <div style={{padding:'0 40px 28px',textAlign:'center'}}>
      <div style={{height:1,background:gold,marginBottom:16}}/>
      <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:600,color:'#111'}}>Thank you for choosing {s.name}.</div>
      <div style={{fontSize:11,color:'#666',marginTop:8}}>{[s.phone,s.facebook,s.address].filter(Boolean).join('  ·  ')}</div>
    </div>
  </div>
})
