# RIHAM Business Manager
```
npm install
npm run dev        # local
npm run build      # production build -> dist/
```
Deploy: push to GitHub → import in Vercel (framework: Vite, defaults). Data is stored in the browser (LocalStorage) — use Settings → Download Backup regularly.
